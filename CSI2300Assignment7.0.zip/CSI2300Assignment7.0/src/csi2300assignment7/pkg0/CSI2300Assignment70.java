/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package csi2300assignment7.pkg0;

import java.io.*;
import java.util.Random;
import java.util.Scanner; 

/**
 *
 * @author sstan
 */
public class CSI2300Assignment70 {
    public static int[] createRandomArray(int arrayLength) {
        Random random = new Random(); 
        int[] array = new int[arrayLength]; 
        int i; 
        for (i = 0; i < arrayLength; i++) {
            array[i] = random.nextInt(101); 
        } // end of for 
        return array;  
    } // create random array
    
    /**
     *
     * @param array
     */
    public static void writeArrayToFile(int[] array, String file) {
        try {
            FileWriter write = new FileWriter(file); 
            int i;
            for (i = 0; i < array.length; i++) {
                write.write(String.valueOf(array[i])); 
                write.write("\n");
            } // end for
            write.close(); 
        } catch (IOException ex) {
            System.out.println("An error has occured");
            ex.printStackTrace(); 
        } // end of catch
    }
    
    public static int[] readFiletoArray(String file) {
        int[] array = null; 
        
        try {
            Scanner scanner; 
            scanner = new Scanner(new File(file));
            int arraylength = 0; 
            while (scanner.hasNextLine()) {
                arraylength++; 
                scanner.nextLine(); 
            } // end of while 
            
        scanner.close();
        int arrayLength = 0;
        array = new int[arrayLength]; 
        Scanner arrayScanner; 
        arrayScanner = newScanner(new File(file));
        while (arrayScanner.hasNextLine()) {
            int i = 0; 
            array[i++] = Integer.parseInt(arrayScanner.nextLine()); 
        } // end of while
        arrayScanner.close();
               
        } /* end of try */ catch(FileNotFoundException ex) {
            System.out.println("404 error, file not found");
        }
        return array; 
    
}
    
    /**
     *
     * @param array
     */
    public static void bubbleSort(int[] array) {
        int j;
        int arrayLength = 0;
        j = arrayLength;
        
        int i; 
        int k = 0; 
        for (i = 0; i < j; i++) {
            if (array[k] > array[k + 1]) {
                int temp = array[k];
                array[k] = array[k + 1];
                array[k + 1] = temp;

            }   // end of if
        } // end of for
        }

    public static void main(String[] args) {
        /*1*/ System.out.println("Enter 1 to randomly generate an array of integers then place it inside a file");
        /*2*/ System.out.println("Enter 2 to read an file containing the list of integers, "
                    + "sort it and store it in another file"); 
        Scanner scan = new Scanner(System.in);
        int opt = scan.nextInt();
        
        if (opt == 1) {
            System.out.println("Enter the Array Length: ");
            int arrayLength = scan.nextInt(); 
            int[] array = createRandomArray(arrayLength); 
            System.out.println("Filename: ");
            String fileName = scan.next();
            writeArrayToFile(array, fileName);
            
            System.out.println("The array has been successfully " +
                               "written to the file");
        } /* end of if */ else {
                            if (opt == 2) {
                                System.out.println("Filename: ");
                                String fileName = scan.next(); 
                                int[] array; 
                                array = readFiletoArray(fileName);
                                if (array != null) {
                                    bubbleSort(array); 
                                    System.out.println("Enter the name of file to store in the "
                                                        + "sorted array"); 
                                    String outputFileName = scan.next(); 
                                    writeArrayToFile(array, outputFileName);
                                    
                                    System.out.println("The sorted array has been successfully written "
                                                        + "to the file");
                                } // end of if (array != null)
                            } /* end of if (opt == 2) */ else {
                                                                System.out.println("Error: Invalid Opt"); 
                                                              } // end of else (invalid)
                           } // end of else
                           scan.close(); 
        
    }

    private static Scanner newScanner(File file) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
} // end
    
    
    
    
  
